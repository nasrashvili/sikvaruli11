
let password = prompt('პაროლი')
if ( password  == '20002001') {
  prompt("სწორია")
 
} else {
 prompt('მოინდომე')
}
let lovefor = prompt('წარმატების საიდუმლო')
if ( lovefor == 'სიყვარულია') {
  prompt("სწორია")
 
} else {
 prompt('მე მჯერა შენი ... განაგრძე')
}

var   number = prompt('Luka')
if (  number == ' nasrashvili') {
  prompt("+1 929 715 45 45 ")
 
} else {
 prompt('site by : Nasrashvili luka')
}
